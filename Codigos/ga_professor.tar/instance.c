#include "instance.h"
#include <stdlib.h>
#include <stdio.h>

Instance *readInstance( const char *fileName )
{
   Instance *inst = malloc( sizeof(Instance) );
   
   FILE *f = fopen( fileName, "r" );
   if ( f ==NULL )
   {
      fprintf( stderr, "fileName %s not found.\n", fileName );
      abort();
   }
   
   fscanf( f, "%d", &(inst->n) );
   fscanf( f, "%d", &(inst->capacity) );

   inst->weight = malloc( sizeof(int)*inst->n );
   inst->profit = malloc( sizeof(int)*inst->n );

   int i;
   for ( i=0; (i<inst->n) ; i++ ) 
      fscanf( f, "%d", &(inst->weight[i]) );
   for ( i=0; (i<inst->n) ; i++ ) 
      fscanf( f, "%d", &(inst->profit[i]) );

   fclose( f );
  
   return inst;
}
